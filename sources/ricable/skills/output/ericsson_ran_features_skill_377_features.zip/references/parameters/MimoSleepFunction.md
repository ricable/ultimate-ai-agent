# MimoSleepFunction Parameters

**Total Parameters**: 17

## Parameter List

### Used in MIMO Sleep Mode

#### MimoSleepFunction.portMerging4TxOpMode
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.portMergingEnabled
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.portMergingOptionFor4TxTo2Tx
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.rank2Enabled
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.sleepEndTime
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.sleepEndTimeApplied
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.sleepMode
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.sleepPowerControl
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.sleepStartTime
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.sleepStartTimeApplied
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.sleepState
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.switchDownMonitorDurTimer
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.switchDownPrbThreshold
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.switchDownRrcConnThreshold
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.switchUpMonitorDurTimer
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.switchUpPrbThreshold
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

#### MimoSleepFunction.switchUpRrcConnThreshold
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

---

