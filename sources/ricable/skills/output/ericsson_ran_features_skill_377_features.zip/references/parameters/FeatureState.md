# FeatureState Parameters

**Total Parameters**: 2

## Parameter List

### Used in TM8 Mode Switching

#### FeatureState.featureState
- **Type**: Unknown
- **Feature**: FAJ 121 4508
- **Description**: Parameter mentioned in documentation

---

### Used in Cell ID-Based Location Support

#### FeatureState.featureState
- **Type**: Unknown
- **Feature**: FAJ 121 0735
- **Description**: Parameter mentioned in documentation

---

