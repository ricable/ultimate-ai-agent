# SectorCarrier Parameters

**Total Parameters**: 1

## Parameter List

### Used in MIMO Sleep Mode

#### SectorCarrier.noOfMutedTxAntennas
- **Type**: Introduced
- **Feature**: FAJ 121 3094
- **Description**: See MOM description.

---

