# EVENT_PARAM_MIMO_SLEEP_DESIRED_TX_CONFIG Parameters

**Total Parameters**: 1

### INTERNAL_PROC_MIMO_SLEEP_SWITCHED

**MO Class**: Unknown
**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: The number of TX antennas desired on the cell sector carriers at                                     the time of MIMO sleep switch.
