# EVENT_PARAM_MIMO_SLEEP_MODE Parameters

**Total Parameters**: 2

### INTERNAL_EVENT_MIMO_SLEEP_DETECTED

**MO Class**: Unknown
**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Mode for MIMO sleep switching.

### INTERNAL_PROC_MIMO_SLEEP_SWITCHED

**MO Class**: Unknown
**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Mode for MIMO Sleep switching
