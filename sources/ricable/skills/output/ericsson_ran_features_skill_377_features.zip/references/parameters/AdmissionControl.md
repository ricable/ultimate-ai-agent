# AdmissionControl Parameters

**Total Parameters**: 1

## Parameter List

### Used in Dynamic PUCCH

#### AdmissionControl.limitSrNonPa
- **Type**: Unknown
- **Feature**: FAJ 121 4377
- **Description**: Parameter mentioned in documentation

---

