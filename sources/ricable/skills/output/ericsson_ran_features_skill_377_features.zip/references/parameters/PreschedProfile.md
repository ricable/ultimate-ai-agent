# PreschedProfile Parameters

**Total Parameters**: 6

## Parameter List

### Used in Prescheduling

#### PreschedProfile.preschedulingDataSize  PreschedulingProfile.preschedulingDataSize
- **Type**: Introduced
- **Feature**: FAJ 121 3085
- **Description**: See MOM description.

#### PreschedProfile.preschedulingPeriod  PreschedulingProfile.preschedulingPeriod
- **Type**: Introduced
- **Feature**: FAJ 121 3085
- **Description**: See MOM description.

#### PreschedProfile.preschedulingDuration  PreschedulingProfile.preschedulingDuration
- **Type**: Introduced
- **Feature**: FAJ 121 3085
- **Description**: See MOM description.

#### PreschedProfile.preschedulingDataSize
- **Type**: Unknown
- **Feature**: FAJ 121 3085
- **Description**: Parameter mentioned in documentation

#### PreschedProfile.preschedulingPeriod
- **Type**: Unknown
- **Feature**: FAJ 121 3085
- **Description**: Parameter mentioned in documentation

#### PreschedProfile.preschedulingDuration
- **Type**: Unknown
- **Feature**: FAJ 121 3085
- **Description**: Parameter mentioned in documentation

---

