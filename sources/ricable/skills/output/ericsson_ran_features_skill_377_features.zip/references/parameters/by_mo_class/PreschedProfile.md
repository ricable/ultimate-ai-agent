# PreschedProfile Parameters

**Total Parameters**: 6

## Parameter Details

### PreschedProfile.preschedulingDataSize

**Type**: Unknown
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: Parameter mentioned in documentation

### PreschedProfile.preschedulingDataSize  PreschedulingProfile.preschedulingDataSize

**Type**: Introduced
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: See MOM description.

### PreschedProfile.preschedulingDuration

**Type**: Unknown
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: Parameter mentioned in documentation

### PreschedProfile.preschedulingDuration  PreschedulingProfile.preschedulingDuration

**Type**: Introduced
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: See MOM description.

### PreschedProfile.preschedulingPeriod

**Type**: Unknown
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: Parameter mentioned in documentation

### PreschedProfile.preschedulingPeriod  PreschedulingProfile.preschedulingPeriod

**Type**: Introduced
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: See MOM description.
