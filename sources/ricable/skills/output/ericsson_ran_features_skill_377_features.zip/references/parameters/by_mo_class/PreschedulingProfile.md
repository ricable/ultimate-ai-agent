# PreschedulingProfile Parameters

**Total Parameters**: 3

## Parameter Details

### PreschedulingProfile.preschedulingDataSize

**Type**: Unknown
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: Parameter mentioned in documentation

### PreschedulingProfile.preschedulingDuration

**Type**: Unknown
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: Parameter mentioned in documentation

### PreschedulingProfile.preschedulingPeriod

**Type**: Unknown
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: Parameter mentioned in documentation
