# Uen Parameters

**Total Parameters**: 5

## Parameter Details

### Uen.AC

**Type**: Unknown
**Used in Feature**: TM8 Mode Switching (FAJ 121 4508)
**Description**: Parameter mentioned in documentation

### Uen.AS

**Type**: Unknown
**Used in Feature**: Cell ID-Based Location Support (FAJ 121 0735)
**Description**: Parameter mentioned in documentation

### Uen.AY

**Type**: Unknown
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: Parameter mentioned in documentation

### Uen.BC

**Type**: Unknown
**Used in Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Parameter mentioned in documentation

### Uen.EC33B

**Type**: Unknown
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Parameter mentioned in documentation
