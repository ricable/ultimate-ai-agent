# FeatureState Parameters

**Total Parameters**: 2

## Parameter Details

### FeatureState.featureState

**Type**: Unknown
**Used in Feature**: TM8 Mode Switching (FAJ 121 4508)
**Description**: Parameter mentioned in documentation

### FeatureState.featureState

**Type**: Unknown
**Used in Feature**: Cell ID-Based Location Support (FAJ 121 0735)
**Description**: Parameter mentioned in documentation
