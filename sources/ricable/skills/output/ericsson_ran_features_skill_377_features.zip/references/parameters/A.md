# A Parameters

**Total Parameters**: 1

## Parameter List

### Used in Cell ID-Based Location Support

#### A.a
- **Type**: Unknown
- **Feature**: FAJ 121 0735
- **Description**: Parameter mentioned in documentation

---

