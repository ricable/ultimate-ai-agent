# ENodeBFunction Parameters

**Total Parameters**: 2

## Parameter List

### Used in Prescheduling

#### ENodeBFunction.initPreschedulingEnable
- **Type**: Introduced
- **Feature**: FAJ 121 3085
- **Description**: See MOM description.

---

### Used in Cell ID-Based Location Support

#### ENodeBFunction.locationReportForPSCell
- **Type**: Introduced
- **Feature**: FAJ 121 0735
- **Description**: See MOM description.(1)

---

