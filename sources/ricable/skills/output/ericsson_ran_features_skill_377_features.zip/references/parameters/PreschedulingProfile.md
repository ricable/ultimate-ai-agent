# PreschedulingProfile Parameters

**Total Parameters**: 3

## Parameter List

### Used in Prescheduling

#### PreschedulingProfile.preschedulingDataSize
- **Type**: Unknown
- **Feature**: FAJ 121 3085
- **Description**: Parameter mentioned in documentation

#### PreschedulingProfile.preschedulingPeriod
- **Type**: Unknown
- **Feature**: FAJ 121 3085
- **Description**: Parameter mentioned in documentation

#### PreschedulingProfile.preschedulingDuration
- **Type**: Unknown
- **Feature**: FAJ 121 3085
- **Description**: Parameter mentioned in documentation

---

