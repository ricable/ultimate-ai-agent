# Uen Parameters

**Total Parameters**: 5

## Parameter List

### Used in TM8 Mode Switching

#### Uen.AC
- **Type**: Unknown
- **Feature**: FAJ 121 4508
- **Description**: Parameter mentioned in documentation

---

### Used in Prescheduling

#### Uen.AY
- **Type**: Unknown
- **Feature**: FAJ 121 3085
- **Description**: Parameter mentioned in documentation

---

### Used in Cell ID-Based Location Support

#### Uen.AS
- **Type**: Unknown
- **Feature**: FAJ 121 0735
- **Description**: Parameter mentioned in documentation

---

### Used in MIMO Sleep Mode

#### Uen.EC33B
- **Type**: Unknown
- **Feature**: FAJ 121 3094
- **Description**: Parameter mentioned in documentation

---

### Used in Dynamic PUCCH

#### Uen.BC
- **Type**: Unknown
- **Feature**: FAJ 121 4377
- **Description**: Parameter mentioned in documentation

---

