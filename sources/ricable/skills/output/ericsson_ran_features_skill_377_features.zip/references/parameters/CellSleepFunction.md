# CellSleepFunction Parameters

**Total Parameters**: 2

## Parameter List

### Used in MIMO Sleep Mode

#### CellSleepFunction.sleepEndTimeApplied
- **Type**: Affecting
- **Feature**: FAJ 121 3094
- **Description**: This attribute is set automatically by the feature.

#### CellSleepFunction.sleepStartTimeApplied
- **Type**: Affecting
- **Feature**: FAJ 121 3094
- **Description**: This attribute is set automatically by the feature.

---

