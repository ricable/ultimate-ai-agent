# LTE Features

**Total Features**: 5

- **Cell ID-Based Location Support** (FAJ 121 0735)
  - Package: LTE Base Package

- **Dynamic PUCCH** (FAJ 121 4377)
  - Package: Uplink Spectrum Adaptations

- **MIMO Sleep Mode** (FAJ 121 3094)
  - Package: Energy Efficiency

- **Prescheduling** (FAJ 121 3085)
  - Package: LTE Base Package

- **TM8 Mode Switching** (FAJ 121 4508)
  - Package: LTE Base Package
