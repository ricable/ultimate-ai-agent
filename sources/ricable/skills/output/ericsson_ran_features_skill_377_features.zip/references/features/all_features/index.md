# All Features

**Total Features**: 5

Complete list of all Ericsson RAN features.

- [Cell ID-Based Location Support](FAJ_121_0735.md) (FAJ 121 0735)
- [Prescheduling](FAJ_121_3085.md) (FAJ 121 3085)
- [MIMO Sleep Mode](FAJ_121_3094.md) (FAJ 121 3094)
- [Dynamic PUCCH](FAJ_121_4377.md) (FAJ 121 4377)
- [TM8 Mode Switching](FAJ_121_4508.md) (FAJ 121 4508)
