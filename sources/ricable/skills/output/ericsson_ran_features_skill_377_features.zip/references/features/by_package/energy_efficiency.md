# Energy Efficiency

**Total Features**: 1

## Package Overview

This value package contains 1 features.

## Features in Package

- **MIMO Sleep Mode** (FAJ 121 3094)
  - CXC: CXC4011808
  - Access: LTE
