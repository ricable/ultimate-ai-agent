# Energy Efficiency

**Total Features**: 1

## Category Overview

This category contains 1 features related to energy efficiency.

## Features

### MIMO Sleep Mode

**FAJ ID**: FAJ 121 3094
**CXC Code**: CXC4011808
**Access Type**: LTE
**Value Package**: Energy Efficiency
**Node Type**: Baseband Radio Node

**Description**: The MIMO Sleep Mode feature is an energy efficiency feature that saves energy by

**Technical Details**:
- Parameters: 43
- Counters: 22
- Events: 20
- Has activation procedure: Yes
