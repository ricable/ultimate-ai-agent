# Technology Categories

Features categorized by radio technology standard.

## 4G LTE (5 features)

- [Cell ID-Based Location Support](technology/4g_lte.md#cell-id-based-location-support) (FAJ 121 0735)
- [Dynamic PUCCH](technology/4g_lte.md#dynamic-pucch) (FAJ 121 4377)
- [MIMO Sleep Mode](technology/4g_lte.md#mimo-sleep-mode) (FAJ 121 3094)
- [Prescheduling](technology/4g_lte.md#prescheduling) (FAJ 121 3085)
- [TM8 Mode Switching](technology/4g_lte.md#tm8-mode-switching) (FAJ 121 4508)
