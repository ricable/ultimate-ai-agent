# MIMO Performance Counters

**Total Counters**: 2

## Counter List

### Used in MIMO Sleep Mode

#### pmMimoSleepOppTime
- **Feature**: FAJ 121 3094
- **Description**: Performance counter pmMimoSleepOppTime

#### pmMimoSleepTime
- **Feature**: FAJ 121 3094
- **Description**: Performance counter pmMimoSleepTime

---

