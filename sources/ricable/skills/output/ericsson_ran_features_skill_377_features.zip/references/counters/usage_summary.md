# Counter Usage Summary

Most frequently used performance counters.

### Most Used Counters

- **pmcounters**: Used in 2 features
- **pmcounter**: Used in 2 features
- **pmActiveUeUlPresched**: Used in 1 features
- **pmActiveUeUlPreschedData**: Used in 1 features
- **pmCounter**: Used in 1 features
- **pmCounters**: Used in 1 features
- **pmPdcchCceUsedUlPresched**: Used in 1 features
- **pmPrbUsedUlPresched**: Used in 1 features
- **pment**: Used in 1 features
- **pmevents**: Used in 1 features
- **pmMimoSleepOppTime**: Used in 1 features
- **pmMimoSleepTime**: Used in 1 features
- **pmPdcpPktDiscDlAqm**: Used in 1 features
- **pmPdcpPktDiscDlPelr**: Used in 1 features
- **pmRadioThpVolDlSCellExt**: Used in 1 features
- **pmRadioThpVolTxDlSCellExt**: Used in 1 features
- **pmRadioTxRankDistr**: Used in 1 features
- **pmTxOffRatio**: Used in 1 features
- **pmTxOffRatio1**: Used in 1 features
- **pmTxOffRatio2**: Used in 1 features
