# Performance Counter Quick Reference

Key performance counters for monitoring.

### Key Performance Counters

#### pmcounters
- **Category**: General
- **Used in**: 2 features
- **Description**: Performance counter pmcounters...

#### pmcounter
- **Category**: General
- **Used in**: 2 features
- **Description**: Performance counter pmcounter...

#### pmActiveUeUlPresched
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmActiveUeUlPresched...

#### pmActiveUeUlPreschedData
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmActiveUeUlPreschedData...

#### pmCounter
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmCounter...

#### pmCounters
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmCounters...

#### pmPdcchCceUsedUlPresched
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmPdcchCceUsedUlPresched...

#### pmPrbUsedUlPresched
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmPrbUsedUlPresched...

#### pment
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pment...

#### pmevents
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmevents...

#### pmMimoSleepOppTime
- **Category**: MIMO
- **Used in**: 1 features
- **Description**: Performance counter pmMimoSleepOppTime...

#### pmMimoSleepTime
- **Category**: MIMO
- **Used in**: 1 features
- **Description**: Performance counter pmMimoSleepTime...

#### pmPdcpPktDiscDlAqm
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmPdcpPktDiscDlAqm...

#### pmPdcpPktDiscDlPelr
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmPdcpPktDiscDlPelr...

#### pmRadioThpVolDlSCellExt
- **Category**: General
- **Used in**: 1 features
- **Description**: Performance counter pmRadioThpVolDlSCellExt...

