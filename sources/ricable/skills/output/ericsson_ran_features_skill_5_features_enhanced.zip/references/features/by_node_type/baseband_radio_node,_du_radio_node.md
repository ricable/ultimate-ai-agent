# Baseband Radio Node, DU Radio Node Features

**Total Features**: 1

- **Prescheduling** (FAJ 121 3085)
