# Baseband Radio Node Features

**Total Features**: 4

- **Cell ID-Based Location Support** (FAJ 121 0735)

- **Dynamic PUCCH** (FAJ 121 4377)

- **MIMO Sleep Mode** (FAJ 121 3094)

- **TM8 Mode Switching** (FAJ 121 4508)
