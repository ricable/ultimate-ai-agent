# LTE Base Package

**Total Features**: 3

## Package Overview

This value package contains 3 features.

## Features in Package

- **Cell ID-Based Location Support** (FAJ 121 0735)
  - CXC: CXC4010841
  - Access: LTE

- **Prescheduling** (FAJ 121 3085)
  - CXC: CXC4011715
  - Access: LTE

- **TM8 Mode Switching** (FAJ 121 4508)
  - CXC: CXC4011996
  - Access: LTE
