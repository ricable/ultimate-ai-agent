# Uplink Spectrum Adaptations

**Total Features**: 1

## Package Overview

This value package contains 1 features.

## Features in Package

- **Dynamic PUCCH** (FAJ 121 4377)
  - CXC: CXC4011955
  - Access: LTE
