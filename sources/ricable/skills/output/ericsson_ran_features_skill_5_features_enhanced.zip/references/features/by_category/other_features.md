# Other Features

**Total Features**: 1

## Category Overview

This category contains 1 features related to other features.

## Features

### Prescheduling

**FAJ ID**: FAJ 121 3085
**CXC Code**: CXC4011715
**Access Type**: LTE
**Value Package**: LTE Base Package
**Node Type**: Baseband Radio Node, DU Radio Node

**Description**: The Prescheduling feature minimizes the round-trip time. It gives PUSCH grants to UEs in

**Technical Details**:
- Parameters: 12
- Counters: 8
- Events: 0
- Has activation procedure: Yes
