# EVENT_PARAM_MIMO_SLEEP_DET_UES Parameters

**Total Parameters**: 1

### INTERNAL_EVENT_MIMO_SLEEP_DETECTED

**MO Class**: Unknown
**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: The PM counters and events of this feature only suggest the                                     duration andThe adjusted number of RRC connections found during                                     the MIMO sleep detection.
