# Affected Parameters

**Total Parameters**: 1

### EUtranCellFDD.noOfPucchFormat1PrbPairsPerFrame

**MO Class**: EUtranCellFDD
**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: The default value is changed by this feature during dynamic                                 operation.
