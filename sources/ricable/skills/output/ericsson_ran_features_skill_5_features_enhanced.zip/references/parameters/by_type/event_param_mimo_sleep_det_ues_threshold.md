# EVENT_PARAM_MIMO_SLEEP_DET_UES_THRESHOLD Parameters

**Total Parameters**: 1

### INTERNAL_EVENT_MIMO_SLEEP_DETECTED

**MO Class**: Unknown
**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: The configured number of RRC connections threshold for the MIMO                                     sleep detection.
