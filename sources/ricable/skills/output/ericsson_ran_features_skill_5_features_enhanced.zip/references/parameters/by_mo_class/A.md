# A Parameters

**Total Parameters**: 1

## Parameter Details

### A.a

**Type**: Unknown
**Used in Feature**: Cell ID-Based Location Support (FAJ 121 0735)
**Description**: Parameter mentioned in documentation
