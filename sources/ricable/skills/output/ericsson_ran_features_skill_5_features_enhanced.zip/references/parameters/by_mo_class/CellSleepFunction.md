# CellSleepFunction Parameters

**Total Parameters**: 2

## Parameter Details

### CellSleepFunction.sleepEndTimeApplied

**Type**: Affecting
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: This attribute is set automatically by the feature.

### CellSleepFunction.sleepStartTimeApplied

**Type**: Affecting
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: This attribute is set automatically by the feature.
