# AdmissionControl Parameters

**Total Parameters**: 1

## Parameter Details

### AdmissionControl.limitSrNonPa

**Type**: Unknown
**Used in Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Parameter mentioned in documentation
