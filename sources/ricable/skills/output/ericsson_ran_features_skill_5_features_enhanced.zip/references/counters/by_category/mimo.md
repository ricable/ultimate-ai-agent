# MIMO Counters

**Total Counters**: 2

### pmMimoSleepOppTime

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmMimoSleepOppTime

### pmMimoSleepTime

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmMimoSleepTime
