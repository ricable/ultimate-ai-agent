# General Counters

**Total Counters**: 37

### pmActiveUeUlPresched

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pmActiveUeUlPresched

### pmActiveUeUlPreschedData

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pmActiveUeUlPreschedData

### pmCounter

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pmCounter

### pmCounters

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pmCounters

### pmPdcchCceUsedUlPresched

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pmPdcchCceUsedUlPresched

### pmPdcpPktDiscDlAqm

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmPdcpPktDiscDlAqm

### pmPdcpPktDiscDlPelr

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmPdcpPktDiscDlPelr

### pmPrachPrbOffsetUpdate

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmPrachPrbOffsetUpdate

### pmPrbUsedUlPresched

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pmPrbUsedUlPresched

### pmPucchSrResCongBbm

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmPucchSrResCongBbm

### pmPucchSrResLongUtilCell

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmPucchSrResLongUtilCell

### pmPucchSrResMediumUtilCell

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmPucchSrResMediumUtilCell

### pmPucchSrResShortUtilCell

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmPucchSrResShortUtilCell

### pmPucchSrResUtilBbm

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmPucchSrResUtilBbm

### pmRadioThpVolDlSCellExt

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmRadioThpVolDlSCellExt

### pmRadioThpVolTxDlSCellExt

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmRadioThpVolTxDlSCellExt

### pmRadioTxRankDistr

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmRadioTxRankDistr

### pmSinrPucchDistr

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmSinrPucchDistr

### pmTxOffRatio

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffRatio

### pmTxOffRatio1

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffRatio1

### pmTxOffRatio2

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffRatio2

### pmTxOffRatio3

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffRatio3

### pmTxOffRatio4

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffRatio4

### pmTxOffTime

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffTime

### pmTxOffTime1

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffTime1

### pmTxOffTime2

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffTime2

### pmTxOffTime3

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffTime3

### pmTxOffTime4

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmTxOffTime4

### pmcounter

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmcounter

### pmcounter

**Feature**: Dynamic PUCCH (FAJ 121 4377)
**Description**: Performance counter pmcounter

### pmcounters

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pmcounters

### pmcounters

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmcounters

### pment

**Feature**: Prescheduling (FAJ 121 3085)
**Description**: Performance counter pment

### pmevents

**Feature**: Cell ID-Based Location Support (FAJ 121 0735)
**Description**: Performance counter pmevents

### pmode

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmode

### pmonitorDurTimer

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmonitorDurTimer

### pmonitordurTimer

**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: Performance counter pmonitordurTimer
