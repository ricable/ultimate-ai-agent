# EVENT_PARAM_MIMO_SLEEP_DET_DL_PRB_USAGE Parameters

**Total Parameters**: 1

### INTERNAL_EVENT_MIMO_SLEEP_DETECTED

**MO Class**: Unknown
**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: The adjusted Downlink PRB use percentage during the MIMO sleep                                     detection.
