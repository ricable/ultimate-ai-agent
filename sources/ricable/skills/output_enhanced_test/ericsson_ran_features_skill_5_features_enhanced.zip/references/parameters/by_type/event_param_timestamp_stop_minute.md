# EVENT_PARAM_TIMESTAMP_STOP_MINUTE Parameters

**Total Parameters**: 1

### INTERNAL_PROC_MIMO_SLEEP_SWITCHED

**MO Class**: Unknown
**Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: The time stamp when the MIMO sleep switching procedure ends.
