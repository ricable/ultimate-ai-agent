# SectorCarrier Parameters

**Total Parameters**: 1

## Parameter Details

### SectorCarrier.noOfMutedTxAntennas

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.
