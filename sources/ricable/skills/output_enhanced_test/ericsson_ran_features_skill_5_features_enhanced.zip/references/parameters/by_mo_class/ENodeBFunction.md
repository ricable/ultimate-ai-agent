# ENodeBFunction Parameters

**Total Parameters**: 2

## Parameter Details

### ENodeBFunction.initPreschedulingEnable

**Type**: Introduced
**Used in Feature**: Prescheduling (FAJ 121 3085)
**Description**: See MOM description.

### ENodeBFunction.locationReportForPSCell

**Type**: Introduced
**Used in Feature**: Cell ID-Based Location Support (FAJ 121 0735)
**Description**: See MOM description.(1)
