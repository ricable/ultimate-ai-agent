# MimoSleepFunction Parameters

**Total Parameters**: 17

## Parameter Details

### MimoSleepFunction.portMerging4TxOpMode

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.portMergingEnabled

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.portMergingOptionFor4TxTo2Tx

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.rank2Enabled

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.sleepEndTime

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.sleepEndTimeApplied

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.sleepMode

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.sleepPowerControl

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.sleepStartTime

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.sleepStartTimeApplied

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.sleepState

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.switchDownMonitorDurTimer

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.switchDownPrbThreshold

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.switchDownRrcConnThreshold

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.switchUpMonitorDurTimer

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.switchUpPrbThreshold

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.

### MimoSleepFunction.switchUpRrcConnThreshold

**Type**: Introduced
**Used in Feature**: MIMO Sleep Mode (FAJ 121 3094)
**Description**: See MOM description.
